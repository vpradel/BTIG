﻿using System;
using System.Configuration;
using System.Net.Http;

namespace BTIG.WebUI.Cats.Initializers
{
    public class HttpClientInitializer
    {
        private static HttpClient client = new HttpClient();

        static HttpClientInitializer()
        {
            client.Timeout = TimeSpan.FromSeconds(Convert.ToDouble(ConfigurationManager.AppSettings["HttpClientTimeout"]));
        }

        public static HttpClient GetHttpClient()
        {
            return client;
        }
    }
}