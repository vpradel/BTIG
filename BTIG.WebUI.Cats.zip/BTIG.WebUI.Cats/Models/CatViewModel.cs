﻿namespace BTIG.WebUI.Cats.Models
{
    public class CatViewModel
    {
        public int CatId { get; set; }
        public string Name { get; set; }

        public string Breed { get; set; }
    }
}