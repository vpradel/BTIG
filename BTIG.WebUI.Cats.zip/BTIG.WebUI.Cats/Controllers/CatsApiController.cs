﻿using System;
using System.Collections.Generic;
using System.Web.Http;
using BTIG.WebUI.Cats.Models;
using System.Text;
using BTIG.DataLayer.Cats;

namespace BTIG.WebUI.Cats.Controllers
{
    public class CatsApiController : ApiController
    {
        [HttpGet]
        public IHttpActionResult Get()
        {
            try
            {
                CatsRepository catRepository = new CatsRepository();

                IList<CatViewModel> cats = new List<CatViewModel>();

                var catsEntity = catRepository.GetAllCats();

                if ((catsEntity != null) && (catsEntity?.Capacity > 0))
                {
                    foreach(var catEntity in catsEntity)
                    {
                        var cat = new CatViewModel();
                        cat.CatId = catEntity.CatId;
                        cat.Name = catEntity.Name;
                        cat.Breed = catEntity.Breed;

                        cats.Add(cat);
                    }
                }

                if (cats.Count == 0)
                {
                    return NotFound();
                }

                return Ok(cats);
            }
            catch (Exception ex) // We could log the Exception somewhere for Audit purposes but this is not a requirement at the moment
            {
                return InternalServerError();
            }
        }

        [HttpPost]
        public IHttpActionResult Create(CatViewModel catModel)
        {
            try
            {
                CatsRepository catRepository = new CatsRepository();
                CatEntity catEntity = new CatEntity();

                string errorMessage = ValidationModel(catModel);
                if (!string.IsNullOrEmpty(errorMessage))
                    return BadRequest($"Validation failure reason for Adding a Cat");

                catEntity.Name = catModel.Name;
                catEntity.Breed = catModel.Breed;

                var catId = catRepository.AddCat(catEntity);

                if (catId > 0)
                {
                    catModel.CatId = catId;
                    return Ok(catModel);
                }
                else
                    return NotFound();
            }
            catch (Exception ex) // We could log the Exception somewhere for Audit purposes but this is not a requirement at the moment
            {
                return InternalServerError();
            }
        }

        [HttpPut]
        public IHttpActionResult Update(CatViewModel catModel)
        {
            try
            {
                CatsRepository catRepository = new CatsRepository();
                CatEntity catEntity = new CatEntity();

                string errorMessage = ValidationModel(catModel);
                if (!string.IsNullOrEmpty(errorMessage))
                    return BadRequest($"Validation failure reason for Updating a Cat");

                catEntity.CatId = catModel.CatId;
                catEntity.Name = catModel.Name;
                catEntity.Breed = catModel.Breed;

                var numOfRowsAffected = catRepository.UpdateCat(catEntity);

                if (numOfRowsAffected > 0)
                    return Ok();
                else
                    return NotFound();
            }
            catch (Exception ex) // We could log the Exception somewhere for Audit purposes but this is not a requirement at the moment
            {
                return InternalServerError();
            }
        }

        private string ValidationModel(CatViewModel catModel)
        {
            if (catModel == null)
                return "Invalid input";

            StringBuilder err = new StringBuilder();

            if (string.IsNullOrWhiteSpace(catModel.Name))
                err.Append("Invalid Cat Name.");

            if (string.IsNullOrWhiteSpace(catModel.Breed))
                err.Append("Invalid Breed.");

            return err.ToString();
        }
    }
}