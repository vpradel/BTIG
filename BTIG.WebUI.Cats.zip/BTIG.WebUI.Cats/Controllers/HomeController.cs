﻿using System;
using System.Collections.Generic;
using System.Web.Mvc;
using BTIG.WebUI.Cats.Initializers;
using BTIG.WebUI.Cats.Models;
using System.Net.Http;
using System.Configuration;
using System.Threading.Tasks;
using System.Text;
using Newtonsoft.Json;

namespace BTIG.WebUI.Cats.Controllers
{
    public class HomeController : Controller
    {
        public async Task<ActionResult> Index()
        {
            IList<CatViewModel> cats = null;

            String url = ConfigurationManager.AppSettings["CatAPIUri"];

            try
            {
                HttpClient _reportClient = HttpClientInitializer.GetHttpClient();

                HttpResponseMessage Response = await _reportClient.GetAsync(url + "CatsApi");

                if (Response?.StatusCode != null && Response.IsSuccessStatusCode)
                    cats = await Response.Content.ReadAsAsync<IList<CatViewModel>>();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return View(cats);
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<JsonResult> Create(CatViewModel catModel)
        {
            CatViewModel cat = null;

            String url = ConfigurationManager.AppSettings["CatAPIUri"];

            try
            {
                HttpClient _reportClient = HttpClientInitializer.GetHttpClient();

                var request = new HttpRequestMessage()
                {
                    RequestUri = new Uri(url + "CatsApi"),
                    Method = HttpMethod.Post,
                    Content = new StringContent(JsonConvert.SerializeObject(catModel), Encoding.UTF8, "application/json"),
                };

                HttpResponseMessage Response = await _reportClient.SendAsync(request);

                if (Response?.StatusCode != null && Response.IsSuccessStatusCode)
                    cat = await Response.Content.ReadAsAsync<CatViewModel>();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Json(cat);
        }

        public async Task<ActionResult> Update(CatViewModel catModel)
        {
            String url = ConfigurationManager.AppSettings["CatAPIUri"];

            try
            {
                HttpClient _reportClient = HttpClientInitializer.GetHttpClient();

                var request = new HttpRequestMessage()
                {
                    RequestUri = new Uri(url + "CatsApi"),
                    Method = HttpMethod.Put,
                    Content = new StringContent(JsonConvert.SerializeObject(catModel), Encoding.UTF8, "application/json"),
                };

                HttpResponseMessage Response = await _reportClient.SendAsync(request);

                if (Response?.StatusCode != null && Response.IsSuccessStatusCode)
                    return new EmptyResult();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return new EmptyResult();
        }
    }
}