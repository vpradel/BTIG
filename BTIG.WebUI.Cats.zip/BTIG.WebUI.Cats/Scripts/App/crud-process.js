﻿function AppendRow(row, catId, name, breed) {
    //Bind CatId.
    $(".CatId", row).find("span").html(catId);

    //Bind Name.
    $(".Name", row).find("span").html(name);
    $(".Name", row).find("input").val(name);

    //Bind Breed.
    $(".Breed", row).find("span").html(breed);
    $(".Breed", row).find("input").val(breed);

    row.find(".Edit").show();
    $("#tblCats").append(row);
};

//Add event handler.
$("body").on("click", "#btnAdd", function () {
    var txtName = $("#txtName");
    var txtBreed = $("#txtBreed");
    $.ajax({
        type: "POST",
        url: "/Home/Create",
        data: '{name: "' + txtName.val() + '", breed: "' + txtBreed.val() + '" }',
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (r) {
            var row = $("#tblCats tr:last-child");
            if ($("#tblCats tr:last-child span").eq(0).html() != "&nbsp;") {
                row = row.clone();
            }
            AppendRow(row, r.CatId, r.Name, r.Breed);
            txtName.val("");
            txtBreed.val("");
        }
    });
});

//Edit event handler.
$("body").on("click", "#tblCats .Edit", function () {
    var row = $(this).closest("tr");
    $("td", row).each(function () {
        if ($(this).find("input").length > 0) {
            $(this).find("input").show();
            $(this).find("span").hide();
        }
    });
    row.find(".Update").show();
    row.find(".Cancel").show();
    $(this).hide();
});

//Update event handler.
$("body").on("click", "#tblCats .Update", function () {
    var row = $(this).closest("tr");
    $("td", row).each(function () {
        if ($(this).find("input").length > 0) {
            var span = $(this).find("span");
            var input = $(this).find("input");
            span.html(input.val());
            span.show();
            input.hide();
        }
    });
    row.find(".Edit").show();
    row.find(".Cancel").hide();
    $(this).hide();

    var cat = {};
    cat.CatId = row.find(".CatId").find("span").html();
    cat.Name = row.find(".Name").find("span").html();
    cat.Breed = row.find(".Breed").find("span").html();
    $.ajax({
        type: "POST",
        url: "/Home/Update",
        data: '{catid: "' + cat.CatId + '", name: "' + cat.Name + '", breed: "' + cat.Breed + '" }',
        contentType: "application/json; charset=utf-8",
        dataType: "json"
    });
});

//Cancel event handler.
$("body").on("click", "#tblCats .Cancel", function () {
    var row = $(this).closest("tr");
    $("td", row).each(function () {
        if ($(this).find("input").length > 0) {
            var span = $(this).find("span");
            var input = $(this).find("input");
            input.val(span.html());
            span.show();
            input.hide();
        }
    });
    row.find(".Edit").show();
    row.find(".Update").hide();
    $(this).hide();
});