﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace BTIG.DataLayer.Cats
{
    public interface ICatsRepository
    {
        List<CatEntity> GetAllCats();
        int AddCat(CatEntity cat);
        int UpdateCat(CatEntity cat);
    }

    public class CatsRepository: ICatsRepository
    {

        public List<CatEntity> GetAllCats()
        {
            var catList = new List<CatEntity>();

            // Create the connection.
            using (SqlConnection connection = new SqlConnection(SettingsDL.Default.DatabaseConnectionString))
            {
                // Define a t-SQL query string
                string sql = "SELECT * FROM CATS";

                // Create a SqlCommand object.
                using (SqlCommand sqlCommand = new SqlCommand(sql, connection))
                {

                    try
                    {
                        connection.Open();

                        // Run the query by calling ExecuteReader().
                        using (SqlDataReader dataReader = sqlCommand.ExecuteReader())
                        {

                            while (dataReader.Read())
                            {
                                // Read every Cat Entity
                                var cat = new CatEntity();
                                cat.CatId = dataReader.GetInt32(0);
                                cat.Name = dataReader.GetString(1);
                                cat.Breed = dataReader.GetString(2);

                                catList.Add(cat);
                            }
                            
                            // Close the SqlDataReader.
                            dataReader.Close();
                        }
                    }
                    catch(Exception ex) // We could log the Exception somewhere for Audit purposes but this is not a requirement at the moment
                    {
                        throw ex;
                    }
                    finally
                    {
                        // Close the connection.
                        connection.Close();
                    }
                }
            }

            return catList;
        }

        public int AddCat(CatEntity cat)
        {
            int CatId = 0;

            // Create the connection.
            using (SqlConnection connection = new SqlConnection(SettingsDL.Default.DatabaseConnectionString))
            {
                // Define a t-SQL query string
                const string sql = "INSERT INTO CATS (Name, Breed) VALUES(@Name, @Breed);SELECT SCOPE_IDENTITY();";

                // Create a SqlCommand object.
                using (SqlCommand sqlCommand = new SqlCommand(sql, connection))
                {

                    try
                    {
                        sqlCommand.Parameters.Add("@Name", SqlDbType.VarChar, 50).Value = cat.Name;
                        sqlCommand.Parameters.Add("@Breed", SqlDbType.VarChar, 50).Value = cat.Breed;

                        connection.Open();

                        CatId = Convert.ToInt32(sqlCommand.ExecuteScalar());
                    }
                    catch(Exception ex) // We could log the Exception somewhere for Audit purposes but this is not a requirement at the moment
                    {
                        return 0;
                    }
                    finally
                    {
                        // Close the connection.
                        connection.Close();
                    }
                }
            }

            return CatId;
        }

        public int UpdateCat(CatEntity cat)
        {
            int NumOfRows = 0;

            // Create the connection.
            using (SqlConnection connection = new SqlConnection(SettingsDL.Default.DatabaseConnectionString))
            {
                // Define a t-SQL query string
                string sql = $"UPDATE CATS SET NAME = '{cat.Name}', BREED = '{cat.Breed}' WHERE CATID = {cat.CatId}";

                // Create a SqlCommand object.
                using (SqlCommand sqlCommand = new SqlCommand(sql, connection))
                {

                    try
                    {
                        connection.Open();

                        NumOfRows = sqlCommand.ExecuteNonQuery();
                    }
                    catch (Exception ex)   // We could log the Exception somewhere for Audit purposes but this is not a requirement at the moment
                    {
                        return 0;
                    }
                    finally
                    {
                        // Close the connection.
                        connection.Close();
                    }
                }
            }

            return NumOfRows;
        }
    }
}
