﻿
namespace BTIG.DataLayer.Cats
{
    public class CatEntity
    {
        public virtual int CatId { get; set; }
        public virtual string Name { get; set; }
        public virtual string Breed { get; set; }
    }
}
